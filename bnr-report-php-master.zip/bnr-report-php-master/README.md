# BNR Reports Web APP for COGEBANK


This will write an excel workbook containing different reports.

## 1. Monthly Deposits - LCY (Local Currency)

## 2. Monthly Deposits - FCY (Foreign Currencies)

## 3. Monthly Deposits Consolidated

## 4. Monthly Deposits by Currency

## 5. Monthly Product Type

## 6. Quaterly Report


